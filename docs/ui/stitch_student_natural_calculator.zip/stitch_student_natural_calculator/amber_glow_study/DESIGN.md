---
name: Amber Glow Study
colors:
  surface: '#fff8f4'
  surface-dim: '#e7d7c9'
  surface-bright: '#fff8f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e5'
  surface-container: '#FFFFFF'
  surface-container-high: '#f5e6d7'
  surface-container-highest: '#f0e0d1'
  on-surface: '#221a12'
  on-surface-variant: '#534434'
  inverse-surface: '#382f25'
  inverse-on-surface: '#feeedf'
  outline: '#867461'
  outline-variant: '#d8c3ad'
  surface-tint: '#855300'
  primary: '#855300'
  on-primary: '#ffffff'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#ffb95f'
  secondary: '#795900'
  on-secondary: '#ffffff'
  secondary-container: '#ffc329'
  on-secondary-container: '#6f5100'
  tertiary: '#00658b'
  on-tertiary: '#ffffff'
  tertiary-container: '#1abdff'
  on-tertiary-container: '#004966'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#ffdf9f'
  secondary-fixed-dim: '#f9bd22'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#c5e7ff'
  tertiary-fixed-dim: '#7fd0ff'
  on-tertiary-fixed: '#001e2d'
  on-tertiary-fixed-variant: '#004c6a'
  background: '#fff8f4'
  on-background: '#221a12'
  surface-variant: '#f0e0d1'
  surface-bg: '#F9FAFB'
  error-red: '#EF4444'
  success-green: '#10B981'
  text-main: '#1F2937'
  text-muted: '#6B7280'
  border-soft: '#E5E7EB'
typography:
  headline-lg:
    fontFamily: Quicksand
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  result-display:
    fontFamily: Quicksand
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max-width: 480px
  margin-mobile: 1rem
  margin-desktop: 2rem
  gutter: 1rem
  stack-gap: 1.5rem
---

## Brand & Style

The design system is built for middle and high school students, prioritizing a **modern, friendly, and encouraging** learning environment. The brand personality is that of a "helpful study companion"—reliable and clear, yet energetic enough to reduce the friction of mathematical tasks.

The visual direction follows a **Modern / Soft-Tactile** style. It utilizes heavy whitespace to reduce cognitive load, combined with vibrant Amber accents to draw focus to primary actions. The interface uses soft depth and generous tap targets to ensure accessibility and comfort, particularly on mobile devices where students are likely to interact with the app.

- **Minimalist Layout:** Keeps the focus on the calculation inputs and results.
- **Soft Depth:** Uses subtle shadows and tonal layering to separate the calculator card from the background.
- **High-Contrast Interaction:** Large, vibrant buttons make the primary "Tính" (Calculate) action unmistakable.

## Colors

This design system uses a warm, energetic palette centered around **Amber** to evoke a sense of optimism and focus.

- **Primary & Secondary:** Used for the main action buttons and brand highlights. Vibrant Orange (#F59E0B) is reserved for the most important interactive elements.
- **Surface & Neutrals:** A clean "Off-White" (#F9FAFB) background keeps the UI airy, while pure white is used for the central calculator card to provide elevation.
- **Semantic Colors:** 
    - **Error Red:** High visibility for validation messages ("Vui lòng nhập số").
    - **Success Green:** Used exclusively for the final result state to provide positive reinforcement.
- **Text:** Deep Charcoal (#1F2937) ensures AAA accessibility for legibility, while a muted gray is used for secondary descriptions.

## Typography

The system uses a pairing of **Quicksand** and **Inter**. 

- **Quicksand** is used for headlines and the final result display. Its rounded terminals feel approachable and less intimidating for students.
- **Inter** is used for all functional UI elements, inputs, and labels. Its high legibility and neutral character provide the necessary clarity for instructional text.

**Vietnamese Language Support:** Both fonts must be implemented with full diacritic support. Line heights are slightly increased to ensure accents do not clash between lines of text. 

The `result-display` style is a specialized token for the final calculation output ($A + B = Result$), designed to be the visual anchor of the success state.

## Layout & Spacing

This is a single-screen application centered on a **Fixed Grid** logic for desktop and a **Fluid** logic for mobile.

- **Mobile:** All inputs and buttons span the full width of the safe area. A 16px (1rem) margin is maintained on the sides to prevent content from touching the screen edges.
- **Desktop/Tablet:** To prevent input fields from stretching too wide (which hinders readability), the calculator is contained within a card with a maximum width of 480px, centered both horizontally and vertically.
- **The "+" Operator:** On mobile, the "+" symbol is placed centrally between the two inputs in a vertical stack. On wider screens, it can be placed horizontally if space permits, though a vertical column is preferred for consistent mental modeling.
- **Rhythm:** An 8px base unit scales all padding and margins. Vertical spacing between logical blocks (Input group vs. Button group) is set to 24px (1.5rem).

## Elevation & Depth

To create a friendly, tactile feel, the design system avoids harsh black shadows in favor of **Ambient Shadows**.

- **Level 1 (Surface):** The main background is flat.
- **Level 2 (Calculator Card):** A soft, diffused shadow using the Primary color's hue (low opacity) to lift the card: `0px 10px 25px -5px rgba(245, 158, 11, 0.1)`.
- **Level 3 (Interactive):** Buttons use a subtle "pressed" effect. When active, they lose their shadow to simulate physical displacement.

**Tonal Layers:** Input fields use a very subtle light-gray background (#F3F4F6) to define the typing area without needing heavy borders, maintaining the clean, modern aesthetic.

## Shapes

The shape language is consistently **Rounded** (Radius: 0.5rem / 8px).

- **Standard Elements:** Input fields and secondary containers use the base 8px radius.
- **Large Elements:** The main calculator card uses `rounded-xl` (1.5rem) to feel friendly and safe.
- **Interactive Elements:** Primary buttons use `rounded-lg` (1rem) to distinguish them from input fields and provide a more "clickable" appearance.

The use of 0px sharp corners is strictly prohibited to maintain the "friendly student companion" brand personality.

## Components

### Buttons
- **Primary ("Tính"):** Solid `#F59E0B` background with white text. Minimum height of 56px for large tap targets. Bold typography.
- **Secondary ("Tính phép khác"):** Outlined or ghost style. Uses the primary color for text and border. Only appears in the `Result` state.

### Input Fields
- **Number Input:** Must trigger the numeric keyboard on mobile. Features a clear label above the field ("Số thứ nhất"). 
- **States:** 
    - **Default:** Soft gray border.
    - **Focus:** 2px Amber border with a soft glow.
    - **Error:** 2px Red border with red helper text below ("Vui lòng nhập số").

### Result Display
- A dedicated container that appears below the "Tính" button. It uses a success-green tinted background (`#ECFDF5`) and large `result-display` typography to celebrate the successful calculation.

### Feedback & Validation
- **Validation Messages:** Positioned directly under the specific input causing the error. Uses a small icon (exclamation circle) alongside the text for accessibility.
- **Loading State:** The button text changes to "Đang tính..." and the opacity is reduced to 70% to prevent double-submission.